CrossPlatform-AlarmClock
========================

CrossPlatform-AlarmClock is an experiment to build a web-app susceptible of
being installed and run in the Firefox OS (http://www.mozilla.org/en-US/firefox/os/)
and the Tizen (https://www.tizen.org/) platforms making use of the W3C's Web Alarm
API specification (http://www.w3.org/TR/2013/WD-web-alarms-20130205/) as
implemented in Firefox OS (https://developer.mozilla.org/en-US/docs/WebAPI/Alarm)
and in Tizen (https://developer.tizen.org/documentation/articles/alarm-api-guide)
respectively.